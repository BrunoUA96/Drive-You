# jquery_language_translation
Language switcher and translation

## settings
1. create variable with your translation and set the source
2. set the default language (default_lang)
3. set the element with languages (langs)
